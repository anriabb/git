<?php
include 'config.php';
$statusMsg='';

error_reporting(0);


    $first_name=$_POST['first_name'];
    $last_name=$_POST['last_name'];
    $email=$_POST['email'];
    $gender=$_POST['gender'];
    $dob_day = $_POST['dob-day'];
    $dob_month = $_POST['dob-month'];
    $dob_year = $_POST['dob-year'];
    $username=$_POST['username'];
    $password = $_POST['password'];
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
    $bday = $dob_year . '-' . $dob_month . '-' . $dob_day;

    //photo upload code
    $targetDir="uploads/";
    $filename= basename($_FILES["file"]["name"]);
    $targetFilePath=$targetDir. $filename;
    $fileType=pathinfo($targetFilePath, PATHINFO_EXTENSION);
    
    if(isset($_POST["submit"]) && !empty($_FILES["file"]["name"])){
        $allowTypes=array('jpg', 'png', 'gif', 'svg');
            if(in_array($fileType, $allowTypes)){
                if(move_uploaded_file($_FILES["file"]["tmp_name"], $targetFilePath)){
                    $insert=$db->query("INSERT INTO `users` (`first_name`, `last_name`, `email`, `gender`, `bday`, `username`, `password`, `photo`) 
    VALUES ( '$first_name', '$last_name', '$email', '$gender', '$bday', '$username', '$hashed_password', '$filename')");
                    if($insert){
                        $statusMsg = "uploaded";
                    }else{
                        $statusMsg="failed";
                    }
                }else{
                    $statusMsg="error";
                }
            }else{
                $statusMsg="notReliable";
            }
    }else{
        $statusMsg="selectFile";
    }
    echo $statusMsg;
     
    //ending there

    //$sql="INSERT INTO `users` (`first_name`, `last_name`, `email`, `gender`, `bday`, `username`, `password`, `photo`) 
    //VALUES ( '$first_name', '$last_name', '$email', '$gender', '$bday', '$username', '$hashed_password', '$filename')";

    // $result = $conn->query($sql);

    if ($insert == TRUE){

    }else {
        echo "error" ;
    }


?>