<?php 

include "config.php";

    if (isset($_POST['update'])) {

        $username = $_POST['username'];
        $post = $_POST['post'];
        $date = $_POST['date'];


        $sql = "UPDATE `posts` SET `username`='$username',`post`='$post',
        `date`='$date' WHERE `id`='$user_id'";
        $result = $conn->query($sql); 

        if ($result == TRUE) {
            echo "";
        }else{
        }

    } 

if (isset($_GET['id'])) {
    $user_id = $_GET['id']; 
    $sql = "SELECT * FROM `posts` WHERE `id`='$user_id'";
    $result = $conn->query($sql); 
    if ($result->num_rows > 0) {        
        while ($row = $result->fetch_assoc()) {
            $username = $row['username'];
            $post = $row['post'];
            $date = $row['date'];
        } 

    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Edit</title> 
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

    </head>
    <body>
        <style>
#fifty{
    width: 50%;
}
.submit{
    width: 130px;
    height:40px;
    font-family: 'Franklin Gothic Medium';
    background-color: whitesmoke;
    color: black;
    border: solid;
    border-radius: 5px;
    border-width: 2px;
    border-color:black;
}

        </style>
<center>
 <div id="forma">
        <form id="fifty" action="" method="post" width="50%">
<br><br><br><br><br>
            <input type="text" name="username" class="form-control" placeholder="Username" value="<?php echo $username; ?>">
            <input type="hidden" name="user_id" value="<?php echo $id; ?>">
            <br>
            <input type="text" class="form-control" name="post" placeholder="Post" value="<?php echo $post; ?>">
            <br>
            <input type="date" class="form-control" name="date" value="<?php echo $date; ?>">
            <br>

            <input type="submit" class="submit" value="Update" name="update"><br><br>
            <a id="a" href="admin.php">Go Back</a>
        </form> 
                            </div></center>
        </body>
        </html> 
    <?php

    } else{ 
        header('Location: ');
    } 
}

?> 