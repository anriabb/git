<?php
include 'config.php';

session_start();

if(!isset($_SESSION['username'])){
    header("Location: signin.php");
    exit();
}

$statusMsg = '';

if(isset($_POST['submit'])){
    $username = $_SESSION['username'];
    $post = $_POST['post'];
    echo $post;

    $sql = "INSERT INTO posts (username, post) VALUES (?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $username, $post);

    if($stmt->execute()){
        $statusMsg = "Status posted successfully!";
    } else {
        $statusMsg = "Error: " . $stmt->error;
    }
    $stmt->close();

    // Redirect to avoid resubmission on page refresh
    header("Location: " . $_SERVER['PHP_SELF']);
    exit();
}

// Fetch posts to display
$sql = "
    SELECT posts.post, posts.date, users.username 
    FROM posts 
    JOIN users ON posts.username = users.username 
    ORDER BY posts.date DESC";
$result = $conn->query($sql);

$posts = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $posts[] = $row;
    }
}

// Fetch user_id based on session username
$user_id_query = $conn->prepare("SELECT id FROM users WHERE username = ?");
$user_id_query->bind_param("s", $_SESSION['username']);
$user_id_query->execute();
$user_id_result = $user_id_query->get_result();
$user_id_row = $user_id_result->fetch_assoc();
$user_id = $user_id_row['id'];

// Fetch posts to display
$sql = "
    SELECT posts.id, posts.post, posts.date, users.username, 
           (SELECT COUNT(*) FROM likes WHERE likes.post_id = posts.id) AS like_count,
           (SELECT COUNT(*) FROM likes WHERE likes.post_id = posts.id AND likes.user_id = ?) AS user_liked
    FROM posts 
    JOIN users ON posts.username = users.username 
    ORDER BY posts.date DESC";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

$posts = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $posts[] = $row;
    }
}
$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home Page</title>
    <link rel="stylesheet" href="dashboard.css">
    <script src="script.js" defer></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>
    <nav>
        <a href="dashboard.php"><img src="ink.png" alt="" id="logo"></a>
        <a href="dashboard.php"><button class="buttons">Home</button></a>
        <a href="profile.php"><button class="buttons">My Profile</button></a>
        <a href="diagram.php"><button class="buttons">Stats</button></a>
        <a href="logout.php"><button class="buttons">Log Out</button></a>

        <input class="buttons" type="text" id="search" placeholder=" Search...">
    </nav><br>

    <div id="dashboard">
        <div id="first">
            <form method="post" action="">
                <textarea name="post" id="posting" placeholder="Create New Post For Society..."></textarea> <br>
                <center><input type="submit" name="submit" value="Submit" id="submit"></center>
            </form>
            <?php if ($statusMsg): ?>
                <p><?php echo $statusMsg; ?></p>
            <?php endif; ?>
        </div>
        <div id="news">
            <?php if (!empty($posts)): ?>
                <?php foreach ($posts as $post): ?>
                    <div class="post" data-post-id="<?php echo $post['id']; ?>">
                        <span class="usr">@<a href="profile.php"><?php echo htmlspecialchars($post['username']); ?></a></span>
                        <span class="dt"><?php echo $post['date']; ?></span> <br><br>
                        <span class="postingday"><?php echo htmlspecialchars($post['post']); ?></span><br><br>
                       
                        <button class="like-btn"><?php echo $post['user_liked'] ? 'Unlike' : 'Like'; ?></button>
                        <span class="like-count"><?php echo $post['like_count']; ?></span> 
                    </div>

                <?php endforeach; ?>
            <?php else: ?>
                <center><p>No Posts Yet!</p></center>
            <?php endif; ?>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>


<footer>
<center>
    <p class="fot">©Roommate, 2024</p>
    <a class="fot">Cookies</a><br>
    <a class="fot">Terms</a><br>
    <a class="fot">Privacy Policy</a>
</center>
</footer>

<script>
    $(document).ready(function(){
    $('.like-btn').click(function(){
        var postDiv = $(this).closest('.post');
        var postId = postDiv.data('post-id');
        var likeBtn = $(this);
        $.ajax({
            url: 'likes.php',
            type: 'POST',
            data: { post_id: postId },
            dataType: 'json',
            success: function(response){
                if(response.status === 'success'){
                    if(response.action === 'liked'){
                        likeBtn.text('Unlike');
                    } else {
                        likeBtn.text('Like');
                    }
                    var likeCount = postDiv.find('.like-count');
                    likeCount.text(parseInt(likeCount.text()) + (response.action === 'liked' ? 1 : -1));
                }
            }
        });
    });

    //

    //

    $('#search').on('input', function(){
        var searchQuery = $(this).val().toLowerCase();
        $('.post').each(function(){
            var postText = $(this).find('.postingday').text().toLowerCase();
            var username = $(this).find('.usr a').text().toLowerCase();
            if(postText.includes(searchQuery) || username.includes(searchQuery)){
                $(this).show();
            } else {
                $(this).hide();
            }
        });
    });
});

</script>

</body>
</html>
