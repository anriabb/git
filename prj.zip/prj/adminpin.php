<?php
include 'config.php';
session_start();

// Check if the PIN form is submitted
if (isset($_POST['login'])) {
    // Validate PIN
    $entered_pin = $_POST['pin'];

    // Example PIN validation (replace with your actual PIN validation logic)
    $correct_pin = '615090'; // Change this to your actual PIN
    if ($entered_pin === $correct_pin) {
        // Set session variable to indicate admin is logged in
        $_SESSION['admin_logged_in'] = true;
        // Redirect to dashboard
        header("Location: admin.php");
        exit();
    } else {
        
    }
}
?>
<?php if (isset($error)): ?>
    <p><?php echo $error; ?></p>
<?php endif; ?>
</form>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>admin</title>
    <link rel="stylesheet" href="style.css">
</head>
<body><center>
<form method="post" action="" id="pinform">
    <p id="pintitle">admin</p>
    <input type="password" id="pin" name="pin" placeholder="Enter PIN" required><br><br>
    <button type="submit" name="login" id="pinbut">Enter</button><br><br>
    <a href="signin.php">Go Back</a>
</form></center>
</body>
</html>