<?php
include 'config.php';
session_start();

// Check if the user is logged in
if(!isset($_SESSION['username'])){
    echo json_encode(['status' => 'error', 'message' => 'User not logged in']);
    exit();
}

// Check if the post_id is provided in the AJAX request
if(!isset($_POST['post_id'])){
    echo json_encode(['status' => 'error', 'message' => 'Post ID not provided']);
    exit();
}

$username = $_SESSION['username'];
$post_id = $_POST['post_id'];

// Fetch user_id based on username
$user_id_query = $conn->prepare("SELECT id FROM users WHERE username = ?");
$user_id_query->bind_param("s", $username);
$user_id_query->execute();
$user_id_result = $user_id_query->get_result();

// Check if the user_id is fetched successfully
if($user_id_result->num_rows != 1) {
    echo json_encode(['status' => 'error', 'message' => 'User ID not found']);
    exit();
}

$user_id_row = $user_id_result->fetch_assoc();
$user_id = $user_id_row['id'];

// Check if the user has already liked the post
$like_check_query = $conn->prepare("SELECT * FROM dislikes WHERE post_id = ? AND user_id = ?");
$like_check_query->bind_param("ii", $post_id, $user_id);
$like_check_query->execute();
$like_check_result = $like_check_query->get_result();

if ($like_check_result->num_rows > 0) {
    // User already liked the post, so unlike it
    $delete_like_query = $conn->prepare("DELETE FROM dislikes WHERE post_id = ? AND user_id = ?");
    $delete_like_query->bind_param("ii", $post_id, $user_id);
    if ($delete_like_query->execute()) {
        echo json_encode(['status' => 'success', 'action' => 'unliked']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Failed to unlike post']);
    }
} else {
    // User has not liked the post, so like it
    $insert_like_query = $conn->prepare("INSERT INTO dislikes (post_id, user_id) VALUES (?, ?)");
    $insert_like_query->bind_param("ii", $post_id, $user_id);
    if ($insert_like_query->execute()) {
        echo json_encode(['status' => 'success', 'action' => 'liked']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Failed to like post']);
    }
}

// Close prepared statements and database connection
$like_check_query->close();
$user_id_query->close();
$conn->close();
?>
