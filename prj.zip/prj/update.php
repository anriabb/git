<?php 

include "config.php";

    if (isset($_POST['update'])) {

        $first_name = $_POST['first_name'];
        $last_name = $_POST['last_name'];
        $email = $_POST['email'];
        $gender = $_POST['gender'];
        $dob_day = $_POST['dob-day'];
        $dob_month = $_POST['dob-month'];
        $dob_year = $_POST['dob-year'];
        $bday = $dob_year . '-' . $dob_month . '-' . $dob_day;
        $username = $_POST['username']; 
        $password = $_POST['password']; 
        $user_id = $_POST['user_id'];

    //     //photo
    //     $targetDir="uploads/";
    // $filename= basename($_FILES["file"]["name"]);
    // $targetFilePath=$targetDir. $filename;
    // $fileType=pathinfo($targetFilePath, PATHINFO_EXTENSION);
    
    // if(isset($_POST["submit"]) && !empty($_FILES["file"]["name"])){
    //     $allowTypes=array('jpg', 'png', 'gif', 'svg');
    //         if(in_array($fileType, $allowTypes)){
    //             if(move_uploaded_file($_FILES["file"]["tmp_name"], $targetFilePath)){
    //                 $insert=$db->query("INSERT INTO users (photo)
    //                 VALUE('". $filename. "', NOW())");
    //                 if($insert){
    //                     $statusMsg = "uploaded";
    //                 }else{
    //                     $statusMsg="failed";
    //                 }
    //             }else{
    //                 $statusMsg="error";
    //             }
    //         }else{
    //             $statusMsg="notReliable";
    //         }
    // }else{
    //     $statusMsg="selectFile";
    // }    
    // //ending there

        $sql = "UPDATE `users` SET `first_name`='$first_name',`last_name`='$last_name',
        `email`='$email',`gender`='$gender', `bday`='$bday', `username`='$username', 
        `password`='$password' WHERE `id`='$user_id'";
        $result = $conn->query($sql); 

        if ($result == TRUE) {
            echo "Record updated successfully.";
        }else{
            echo "Error:" . $sql . "<br>" . $conn->error;
        }

    } 

if (isset($_GET['id'])) {
    $user_id = $_GET['id']; 
    $sql = "SELECT * FROM `users` WHERE `id`='$user_id'";
    $result = $conn->query($sql); 
    if ($result->num_rows > 0) {        
        while ($row = $result->fetch_assoc()) {
            $first_name = $row['first_name'];
            $last_name = $row['last_name'];
            $email = $row['email'];
            $gender = $row['gender'];
            $bday = $row['bday'];
            $username = $row['username'];
            $password  = $row['password'];
            $id = $row['id'];
        } 

    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Edit</title> <link rel="stylesheet" href="updatestyle.css">
    </head>
    <body>
    <nav>
        <a href="dashboard.php"><img src="ink.png" alt="" id="logo"></a>
        <a href="dashboard.php"><button class="buttons">Home</button></a>
        <a href="profile.php"><button class="buttons">My Profile</button></a>
        <a href="logout.php"><button class="buttons">Log Out</button></a>
        <input class="buttons" type="text" id="search" placeholder=" Search...">
    </nav><br>
            <h2>UPDATE YOUR PROFILE</h2>
 <div id="forma">
        <form action="" method="post">

        <form action="" method="POST" enctype="multipart/form-data">
        <!-- <input  type="file" name="photo" value="Profile" class="form-control" id="photo"><br> -->

            <input type="text" name="first_name" class="form-control" placeholder="  First Name..." value="<?php echo $first_name; ?>">
            <input type="hidden" name="user_id" value="<?php echo $id; ?>">
            <br>
            <input type="text" class="form-control" name="last_name" placeholder="  Last Name..." value="<?php echo $lastname; ?>">
            <br>
            <input type="email" class="form-control" name="email" placeholder="  Email..." value="<?php echo $email; ?>">
            <br>
            <select id="gender" name="gender" class="form-control" >
                <option value="" disabled selected hidden>  Gender...</option>
                <option value="Male">Male</option>
                <option value="Female">Female</option>
            </select>
            <br>
                        <div class="bdayform">
                        <select id="dob-day" name="dob-day" class="form-control" required>
                            <option value="<?php echo $dob_day; ?>" disabled selected hidden>Day</option>
                            <script>
                                for (let i = 1; i <= 31; i++) {
                                    document.write(`<option value="${i}">${i}</option>`);
                                }
                            </script>
                        </select>

                        <select id="dob-month" name="dob-month" class="form-control" required>
                            <option value="" disabled selected hidden>Month</option>
                            <option value="1">January</option>
                            <option value="2">February</option>
                            <option value="3">March</option>
                            <option value="4">April</option>
                            <option value="5">May</option>
                            <option value="6">June</option>
                            <option value="7">July</option>
                            <option value="8">August</option>
                            <option value="9">September</option>
                            <option value="10">October</option>
                            <option value="11">November</option>
                            <option value="12">December</option>
                        </select>

                        <select id="dob-year" name="dob-year" class="form-control" required>
                            <option value="<?php echo $dob_year; ?>" disabled selected hidden>Year</option>
                            <script>
                                const currentYear = new Date().getFullYear();
                                for (let i = currentYear; i >= 1900; i--) {
                                    document.write(`<option value="${i}">${i}</option>`);
                                }
                            </script>
                        </select>
                </div>
                
            <input type="text" name="username" class="form-control" placeholder="  Username..." value="<?php echo $username; ?>">

            <br>
            <input type="password" name="password" class="form-control" placeholder="  Password..." value="<?php echo $password; ?>"><br>
        
            <input type="submit" class="submit" value="Update" name="update"><br><br>
            <a id="a" href="admin.php">Go Back</a>
        </form> 
                            </div>
                            <footer>
<center>
    <p class="fot">©Dead Poet Society, 2024</p>
    <a class="fot">Cookies</a><br>
    <a class="fot">Terms</a><br>
    <a class="fot">Privacy Policy</a>
</center>
</footer>
<style>
h2{
    color: rgba(255, 8, 243, 0.277);
    font-family: 'Franklin Gothic Medium';
    margin-left:41vw;
}
nav{
    display: flex;
    flex-direction: row;
    justify-content: center;
    align-items: center;
    width: 100%;
    height: 10%;
    background-color: rgba(255, 8, 243, 0.277);
}
.buttons{

    height: 30px;
    width: 100px;
    border-radius: 7px;
    margin: 15px;
    cursor: pointer;
    background-color: rgba(221, 128, 255, 0.785);
    color: white;
    border: none;
    font-family: 'Franklin Gothic Medium';

}
.buttons:hover{
    background-color: rgb(255, 255, 255);
    color: rgba(221, 128, 255, 0.785);
}
::placeholder{
    color: white;
    font-family: 'Franklin Gothic Medium';
}
:hover::placeholder{
    color: rgba(221, 128, 255, 0.785);

}
#search{
    margin-left: 300px;
}
#logo{
    width: 50px;
    height: 50px;
    border-radius: 20%;
    margin-right: 350px;
}
::placeholder { 
    font-family:'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif ;
    margin-left: 2px;
    color: gray;
  }

    footer{
    display: flex;
    flex-direction: row;
    justify-content: center;
    align-items: center;
    width: 100%;
    height: 100px;
    background-color: rgba(255, 8, 243, 0.277);
    margin-top:100px;
}
.fot{
    font-size: 10px;
    color: rgb(216, 77, 179);

}
.pot:hover{
    color: rgb(255, 255, 255);
}
    .submit{
    width: 200px;
    height: 40px;
    margin: 5px;
    border-radius: 7px;
    border: none;
    background-color: rgb(140, 43, 230);
    color: white;
    font-weight: 700;
}
    #a{
        margin-left:75px;
    }
    #forma{
    display: flex;
    justify-content: left;

    padding-top: 50px;
    margin-left:40%;
}
</style>
        </body>
        </html> 
    <?php

    } else{ 
        header('Location: profile.php');
    } 
}

?> 