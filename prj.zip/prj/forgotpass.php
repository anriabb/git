<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgotten Password</title>
</head>
<body>
    <div>
        <br>
        <h2>Forgot Password</h2>
        <input type="text" id="email" placeholder="Enter Your Email To Send You The Link..."> <br>
        <input onclick="change()" type="button" value="Send" id="submit"></input> <br>
        <a href="./signin.php">Go Back</a>
    </div>

    <style>
        h2{
            font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;
            color:rgb(140, 43, 230);
        }
        div{
            display: flex;
            flex-direction: column;
            align-items: center;
            margin: auto;
            margin-top: 15vw;
            height: 300px;
            width: 600px;
            background-color: whitesmoke;
            border-radius: 9px;
        }

        input{
            width: 290px;
            height: 40px;
            border-radius: 7px;
            border: none;
            background-color: white;
            margin-top: 2.5vw;
        }
        input::placeholder{
            font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;
            color:gray;
            padding-left: 10px;
        }

        #submit{
            width: 150px;
            height: 40px;
            margin: 5px;
            border-radius: 7px;
            border: none;
            font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;
            background-color: rgb(140, 43, 230);
            color: white;
            font-weight: 700;
        }
        #submit:hover {
            background-color: rgba(140, 43, 230, 0.559);
            cursor: pointer;
        }
        a{
            text-decoration:none;
            color: blueviolet;
            font-family:'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;
        }
        a:hover{
            color: rgba(140, 43, 230, 0.559);
        }
    </style>

    <script>
        function change() {
            document.getElementById("submit").value = "Sent";
            document.getElementById("submit").style.backgroundColor = 'green';
            document.getElementById("email").value = '';

        }
    </script>
</body>
</html>
