<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign In</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <?php
    require("config.php");
    session_start();
    if(isset($_POST['username'])){
        $username = stripslashes($_REQUEST['username']);
        $username = mysqli_real_escape_string($conn, $username);

        $password = stripslashes($_REQUEST['password']);
        $password = mysqli_real_escape_string($conn, $password);

        $query = "SELECT * FROM `users` WHERE username = '$username'";
        $result = mysqli_query($conn, $query) or die(mysqli_error());
        $rows = mysqli_num_rows($result);
        
        if ($rows == 1) {
            $row = mysqli_fetch_assoc($result);
            if (password_verify($password, $row['password'])) {
                $_SESSION['username'] = $username;
                header("Location: dashboard.php");
                exit();
            }else {?>
                <div id="rows">
                <div id="main-title">
                <h1 id="h1">Roommates In Georgia</h1>
                <h3 id="h3">Find a roommate in Georgia...</h3>
    
            </div>
    
    
                <?php
                echo mysqli_error($conn), "<div class='form'>  
                <p class='incorrect'> Incorrect Username or Password  </p>
                <p class='link'> <a href='signin.php'>LOG IN AGAIN</a></p> 
                </div> ";?> </div> <?php
            }
        } else {?>
            <div id="rows">
            <div id="main-title">
            <h1 id="h1">Roommates In Georgia</h1>
            <h3 id="h3">Find a roommate in Georgia...</h3>

        </div>


            <?php
            echo mysqli_error($conn), "<div class='form'>  
            <p class='incorrect'> Incorrect Username or Password  </p>
            <p class='link'> <a href='signin.php'>LOG IN AGAIN</a></p> 
            </div> ";?> </div> <?php
        }
                $result = mysqli_query($conn, $query) or die(mysqli_error());


    
    } else { 
        ?>
        <div id="rows">
        <div id="main-title">
            <h1 id="h1">Roommates In Georgia</h1>
            <h3 id="h3">Find a roommate in Georgia...</h3>

        </div>

        <form action="" class="form" method="post" name="login">
            <h1 class="login-title">SIGN IN</h1>
            <input type="text" class="login-input" name="username" placeholder="  Username..."  autofocus="true">
            <input type="password" class="login-input" name="password" placeholder="  Password...">
            <input type="submit" class="login-button" name="submit" value="Enter">
            <p class="link"><a href="forgotpass.php">Forgot Password?</a></p>
            
            <p id="xazi">_____________________________________________</p>
            <br>
            <a href="signup.php" class="button">SIGN UP</a>
            <br><a href="adminpin.php" id="adminlink">admin</a>
        </form>
        </div>
    <?php
    }
    ?>
    <br><br><br><br><br><br><br>
    <footer>
        <center>
            <p class="fot">©Roommate, 2024</p>
            <a class="fot">Cookies</a><br>
            <a class="fot">Terms</a><br>
            <a class="fot">Privacy Policy</a>
        </center>
    </footer>
</body>
</html>