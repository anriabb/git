<?php
include 'config.php';
session_start();
error_reporting(E_ERROR | E_PARSE);

// Assuming $loggedInUserId contains the ID of the logged-in user
$sql = "SELECT * FROM users";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

</head>
<body>
        
<center>
                    
<div>
    <nav>
        <a href="dashboard.php"><img src="ink.png" alt="" id="logo"></a>
        <a href="dashboard.php"><button class="buttons">Home</button></a>
        <a href="profile.php"><button id="profili" class="buttons">My Profile</button></a>
        <a href="diagram.php"><button class="buttons">Stats</button></a>

        <a href="logout.php"><button class="buttons">Log Out</button></a>
        <input class="buttons" type="text" id="search" placeholder=" Search...">
    </nav><br><br>
    <div id="main">
    <h2 id="title">MY PROFILE</h2><br>
    <table>
        <tbody>
            <?php
            $user_id_query = $conn->query("SELECT * FROM users WHERE username = '".$_SESSION['username']."'");

            error_reporting(E_ERROR | E_PARSE);

            if (TRUE) {
                // while ($row = $result->fetch_assoc()) {
                $row=$user_id_query->fetch_assoc();
                    // if ($row['username'] == $user_id_query) {
            ?>
       
                            <tr><td id="rowss">First Name:</td><td> <?php echo $row['first_name']; ?> </td></tr>
                            <tr><td id="rowss">Last Name:</td><td> <?php echo $row['last_name']; ?> </td></tr>
                            <tr><td id="rowss">Email:</td><td> <?php echo $row['email']; ?> </td></tr>
                            <tr><td id="rowss">Gender:</td><td> <?php echo $row['gender']; ?> </td></tr>
                            <tr><td id="rowss">Date of Birth: <span>___</span></td><td> <?php echo $row['bday']; ?> </td></tr>
                            <tr><td id="rowss">Username:</td><td> <?php echo $row['username']; ?> </td></tr>
                            <tr><td id="rowss">Password:</td><td> <?php echo $row['password']; ?> </td></tr>
                            
                                <a class="btn btn-info" href="update.php?id=<?php echo $row['id']; ?>">Edit</a> <span>__</span>
                                <a class="btn btn-danger" href="delete.php?id=<?php echo $row['id']; ?>">Delete</a>

                            
               
            <?php
                    // }
                // }
            }
            ?>
        </tbody>
        </table>
        <br><br>
</div>

            </tbody>
        </table>
    </div>
    </div>
</center>
    <style>
        #main{
            margin-top: 100px;
        }
        footer{
    display: flex;
    flex-direction: row;
    justify-content: center;
    align-items: center;
    width: 100%;
    height: 100px;
    background-color: rgba(255, 8, 243, 0.277);
    margin-top: 170px;
}
.fot{
    font-size: 10px;
    color: rgb(216, 77, 179);

}
.pot:hover{
    color: rgb(255, 255, 255);
}
        #title{
            font-family: 'Franklin Gothic Medium';
            color: rgba(221, 128, 255, 0.785);
        }
        #profili{
            background-color: rgba(224, 132, 255);

        }
        #profili:hover{
            background-color: rgb(255, 255, 255);
            color: rgba(221, 128, 255, 0.785);
        }
        nav{
    display: flex;
    flex-direction: row;
    justify-content: center;
    align-items: center;
    width: 100%;
    height: 10%;
    background-color: rgba(255, 8, 243, 0.277);
}
.buttons{

    height: 30px;
    width: 100px;
    border-radius: 7px;
    margin: 15px;
    cursor: pointer;
    background-color: rgba(221, 128, 255, 0.785);
    color: white;
    border: none;
    font-family: 'Franklin Gothic Medium';

}
.buttons:hover{
    background-color: rgb(255, 255, 255);
    color: rgba(221, 128, 255, 0.785);
}
::placeholder{
    color: white;
    font-family: 'Franklin Gothic Medium';
}
:hover::placeholder{
    color: rgba(221, 128, 255, 0.785);

}
#search{
    margin-left: 300px;
}
#logo{
    width: 50px;
    height: 50px;
    border-radius: 20%;
    margin-right: 350px;
}
        a{
            text-decoration: none;
            color: blueviolet;
            font-family: 'Franklin Gothic Medium';
        }
        a:hover{
            text-decoration: none;

            color:rgba(137, 43, 226, 0.388) ;

        }
        span{
            color
            : white;
        }
        td{
            font-family: 'Franklin Gothic Medium';
            color: gray;
        }
    </style>
<footer>
<center>
    <p class="fot">©Dead Poet Society, 2024</p>
    <a class="fot">Cookies</a><br>
    <a class="fot">Terms</a><br>
    <a class="fot">Privacy Policy</a>
</center>
</footer>
</body>
</html>