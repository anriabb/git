<?php
include 'config.php';
$statusMsg='';

error_reporting(0);

if(isset($_POST['submit'])){
    $first_name=$_POST['first_name'];
    $last_name=$_POST['last_name'];
    $email=$_POST['email'];
    $gender=$_POST['gender'];
    $dob_day = $_POST['dob-day'];
    $dob_month = $_POST['dob-month'];
    $dob_year = $_POST['dob-year'];
    $username=$_POST['username'];
    $password = $_POST['password'];
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
    $bday = $dob_year . '-' . $dob_month . '-' . $dob_day;
    //photo upload code
    // $targetDir="uploads/";
    // $filename= basename($_FILES["file_image"]["name"]);
    // $targetFilePath=$targetDir. $filename;
    // $fileType=pathinfo($targetFilePath, PATHINFO_EXTENSION);
    
    if(isset($_POST["submit"])){
        
                    $insert=$conn->query("INSERT INTO users (first_name, last_name, email, gender, bday, username, password) 
                        VALUES ( '$first_name', '$last_name', '$email', '$gender', '$bday', '$username', '$hashed_password')");
                    if($insert){
                        $statusMsg = "uploaded";
                    }else{
                        $statusMsg="failed";
                    }
                }else{
                    $statusMsg="error";
                }
                
    // if(isset($_POST["submit"])){
    //     $allowTypes=array('jpg', 'png', 'gif', 'svg');
    //     echo $targetFilePath;
    //             if(move_uploaded_file($_FILES["file"]["tmp_name"], $targetFilePath)){
    //                 $insert=$db->query("INSERT INTO users (first_name, last_name, email, gender, bday, username, password, photo) 
    //                     VALUES ( '$first_name', '$last_name', '$email', '$gender', '$bday', '$username', '$hashed_password', '$targetFilePath')");
    //                 if($insert){
    //                     $statusMsg = "uploaded";
    //                 }else{
    //                     $statusMsg="failed";
    //                 }
    //             }else{
    //                 $statusMsg="error";
    //             }
            
    // }else{
    //     $statusMsg="selectFile";
    // }
    // echo $statusMsg . $filename;
     
    //ending there

    // $sql="INSERT INTO `users` (`first_name`, `last_name`, `email`, `gender`, `bday`, `username`, `password`, `photo`) 
    // VALUES ( '$first_name', '$last_name', '$email', '$gender', '$bday', '$username', '$hashed_password', '$filename')";

    // $result = $conn->query($sql);

    // if ($result == TRUE){

    // }else {
    //     echo "error" ;
    // }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up</title>
    <link rel="stylesheet" href="signup.css">

</head>
<body>
<div id="rows">
        <div id="main-title">
            <h1 id="h1">Join Us</h1>
            <h3 id="h3">Find Your Future Friends...</h3>

        </div>
    <form action="" method="POST">
        <h1 class="login-title">SIGN UP</h1>
        <input type="text" name="first_name" class="form-control" placeholder="  First Name..."> 
        <input type="text" name="last_name" class="form-control" placeholder="  Last Name..."> 
        <input type="text" name="email" class="form-control" placeholder="  Email..."> 
        <select id="gender" name="gender" class="form-control" >
            <option value="">  Gender...</option>
            <option value="Male">Male</option>
            <option value="Female">Female</option>
        </select>

                        <!-- Birthday Form -->
        <div class="bdayform">
            <select id="dob-day" name="dob-day" class="form-control" >
                <option value="" disabled selected hidden>Day</option>
                <script>
                    for (let i = 1; i <= 31; i++) {
                        document.write(`<option value="${i}">${i}</option>`);
                    }
                </script>
            </select>

            <select id="dob-month" name="dob-month" class="form-control" >
                <option value="" disabled selected hidden>Month</option>
                <option value="1">January</option>
                <option value="2">February</option>
                <option value="3">March</option>
                <option value="4">April</option>
                <option value="5">May</option>
                <option value="6">June</option>
                <option value="7">July</option>
                <option value="8">August</option>
                <option value="9">September</option>
                <option value="10">October</option>
                <option value="11">November</option>
                <option value="12">December</option>
            </select>

            <select id="dob-year" name="dob-year" class="form-control" >
                <option value="" disabled selected hidden>Year</option>
                <script>
                    const currentYear = new Date().getFullYear();
                    for (let i = currentYear; i >= 1900; i--) {
                        document.write(`<option value="${i}">${i}</option>`);
                    }
                </script>
            </select><br>
        </div>

        <input type="text" name="username" class="form-control" placeholder="  Username..."> 
        <input type="password" name="password" class="form-control" placeholder="  Password...">    
        <!-- <input  type="file" name="file_image"  class="form-control" id="photo"> -->
        <input type="submit" name="submit" value="SIGN UP" class="submit">
        <p id="xazi">_____________________________________________</p>

        <a href='signin.php'>SIGN IN </a>

    </form>
</div>
    <br><br><br><br><br>
    <footer>
<center>
    <p class="fot">©Roommate, 2024</p>
    <a class="fot">Cookies</a><br>
    <a class="fot">Terms</a><br>
    <a class="fot">Privacy Policy</a>
</center>
</footer>
</body>
</html>