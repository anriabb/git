<?php
include 'config.php';
session_start();


if(isset($_GET['id'])){
    $user_id = $_GET['id'];
    $sql = "DELETE FROM `posts` WHERE `id`=$user_id ";
    $result=$conn->query($sql);

    if($result == TRUE){}
    else{
        echo "error";
    }
}
?>
<center>
<a href="admin.php">Go Back</a></center>

<style>
    a{
        margin-top: 350px;
    }
</style>