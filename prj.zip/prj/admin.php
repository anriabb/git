<?php
include 'config.php';
session_start();

$sql2 = "SELECT * FROM posts";
$result2 = $conn->query($sql2);

$sql = "SELECT * FROM users";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>admin</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

</head>
<body>
        
    <div>
        <h1>USERS</h1><br>
        <table class="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>First Name</th>
                    <th>Lats Name</th>
                    <th>Email</th>
                    <th>Gender</th>
                    <th>Birthday</th>
                    <th>Username</th>
                    <th>Password</th>
                    <th>Photo</th>
                    <th>Action</th>
                </tr>
            </thead>

            <tbody>
                <?php
                if ($result->num_rows>0){
                    while($rows = $result->fetch_assoc()){ ?>
                    <tr>
                        <td> <?php  echo $rows['id'];   ?> </td>
                        <td> <?php  echo $rows['first_name'];   ?> </td>
                        <td> <?php  echo $rows['last_name'];   ?> </td>
                        <td> <?php  echo $rows['email'];   ?> </td>
                        <td> <?php  echo $rows['gender'];   ?> </td>
                        <td> <?php  echo $rows['bday'];   ?> </td>
                        <td> <?php  echo $rows['username'];   ?> </td>
                        <td> <?php  echo $rows['password'];   ?> </td>
                        <td> <?php  echo $rows['photo'];   ?> </td>
                        <td>
                            <a class="btn btn-info" href="update.php?id=<?php echo $rows['id'] ; ?>">Edit</a>
                            <a class="btn btn-danger" href="delete.php?id=<?php echo $rows['id'] ; ?>">Delete</a>
                        </td>
                    </tr>
                    <?php }
                }
                ?>
            </tbody>
        </table>
    </div>

<br><br>

<p>#######################################################################################################################################################################################################</p>

<br><br>

    <h1>POSTS</h1><br>
        <table class="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Username</th>
                    <th>Post</th>
                    <th>Date</th>
                    <th>Action</th>
                </tr>
            </thead>

            <tbody>
                <?php
                if ($result2->num_rows>0){
                    while($rows2 = $result2->fetch_assoc()){ ?>
                    <tr>
                        <td> <?php  echo $rows2['id'];   ?> </td>
                        <td> <?php  echo $rows2['username'];   ?> </td>
                        <td> <?php  echo $rows2['post'];   ?> </td>
                        <td> <?php  echo $rows2['date'];   ?> </td>
                        <td>
                            <a class="btn btn-info" href="updatepost.php?id=<?php echo $rows2['id'] ; ?>">Edit</a>
                            <a class="btn btn-danger" href="deletepost.php?id=<?php echo $rows2['id'] ; ?>">Delete</a>
                        </td>
                    </tr>
                    <?php }
                }
                ?>
            </tbody>
        </table>
    </div>
    <br><br><br><br><br><br>
    <center>
    <a id="a" href="signin.php">Go Back To Start Page</a>
</center>
</body>
</html>