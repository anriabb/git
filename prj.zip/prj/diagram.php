<?php
 require_once 'config.php';

    $sql = "SELECT user_name, place, price FROM diagram";
    $result = $conn->query($sql);

    $user_name = [];
    $place = [];
    $price = [];

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $user_name[] = $row['user_name'];
            $place[] = $row['place'];
            $price[] = $row['price'];
        }
    } else {
        echo "404";
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stats</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
<nav>
        <a href="dashboard.php"><img src="ink.png" alt="" id="logo"></a>
        <a href="dashboard.php"><button class="buttons">Home</button></a>
        <a href="profile.php"><button class="buttons">My Profile</button></a>
        <a href="diagram.php"><button class="buttons">Stats</button></a>
        <a href="logout.php"><button class="buttons">Log Out</button></a>

        <input class="buttons" type="text" id="search" placeholder=" Search...">
    </nav><br><br>
    <center>
    <div id="div">
    <div>
        <h2>Prices In Different Regions</h2> <br>
        <canvas id="myChart" width="100" height="500"></canvas>
    </div>
    <div>
        <h2>Users' Suggested Prices</h2><br>
        <canvas id="myChart2" width="100" height="500"></canvas>
    </div>

    </div>
    </center>

    <script>
        var ctx = document.getElementById('myChart').getContext('2d');
        var chart = new Chart(ctx, {
            type: 'pie',
            data: {
                labels: <?php echo json_encode($place) ?>,
                datasets: [
                    {
                        label: "Users",
                        data: <?php echo json_encode($user_name) ?>,
                        backgroundColor: 'rgb(216, 77, 179, 0.5)',
                        borderColor: 'rgba(255, 8, 243, 0.277)',
                        borderWidth: 1
                    },
                    {
                        label: "~Price",
                        data: <?php echo json_encode($price) ?>,
                        backgroundColor: 'rgb(216, 77, 179, 0.5)',
                        borderColor: 'rgba(255, 8, 243, 0.277)',
                        borderWidth: 1
                    }
                ]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    </script>

    
<script>
        var ctx = document.getElementById('myChart2').getContext('2d');
        var chart = new Chart(ctx, {
            type: 'pie',
            data: {
                labels: <?php echo json_encode($user_name) ?>,
                datasets: [
                    {
                        label: "Users",
                        data: <?php echo json_encode($price) ?>,
                        backgroundColor: 'rgb(216, 77, 179, 0.5)',
                        borderColor: 'rgba(255, 8, 243, 0.277)',
                        borderWidth: 1
                    },
                    {
                        label: "Users",
                        data: <?php echo json_encode($place) ?>,
                        backgroundColor: 'rgb(216, 77, 179, 0.5)',
                        borderColor: 'rgba(255, 8, 243, 0.277)',
                        borderWidth: 1,
                        barThickness: 200

                    }
                ]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    </script>

<style>
    h2{
        font-family: 'Franklin Gothic Medium';
        color: blueviolet;
    }
        #div {
            width: 100%;
            height: 400px;
            margin: auto;
            padding: 10px;
            display: flex;
            flex-direction: row;
        }
        #myChart {
            width: 200px ;
            height: 100% ;
        }
        #myChart2 {
            width: 200px ;
            height: 100% ;
            margin-left: 70px;
        }
        nav{
    display: flex;
    flex-direction: row;
    justify-content: center;
    align-items: center;
    width: 100%;
    height: 10%;
    background-color: rgba(255, 8, 243, 0.277);
}
.buttons{

    height: 30px;
    width: 100px;
    border-radius: 7px;
    margin: 15px;
    cursor: pointer;
    background-color: rgba(221, 128, 255, 0.785);
    color: white;
    border: none;
    font-family: 'Franklin Gothic Medium';

}
.buttons:hover{
    background-color: rgb(255, 255, 255);
    color: rgba(221, 128, 255, 0.785);
}
::placeholder{
    color: white;
    font-family: 'Franklin Gothic Medium';
}
:hover::placeholder{
    color: rgba(221, 128, 255, 0.785);

}
#search{
    margin-left: 300px;
}
#logo{
    width: 50px;
    height: 50px;
    border-radius: 20%;
    margin-right: 350px;
}
footer{
    display: flex;
    flex-direction: row;
    justify-content: center;
    align-items: center;
    width: 100%;
    height: 100px;
    background-color: rgba(255, 8, 243, 0.277);
    margin-top: 110px;
}
.fot{
    font-size: 10px;
    color: rgb(216, 77, 179);

}
.pot:hover{
    color: rgb(255, 255, 255);
}
    </style>
<footer>
<center>
    <p class="fot">©Roommate, 2024</p>
    <a class="fot">Cookies</a><br>
    <a class="fot">Terms</a><br>
    <a class="fot">Privacy Policy</a>
</center>
</footer>
</body>
</html>